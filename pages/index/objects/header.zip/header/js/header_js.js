;(function($){
    $.fn.header_replace_background = function(header_background)
    {
        //alert(header_background);
        this.html(header_background);
        return this;
    };
})(jQuery);