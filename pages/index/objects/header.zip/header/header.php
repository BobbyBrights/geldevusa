<link href="/objects/header/css/header.css" type="text/css" property="stylesheet" rel="stylesheet" />


<div id="header_container">
    <div class="header_front_image" id="header_background_images_wrapper">

        <img src="/objects/header/img/menu/qab/border_gradient.png" id="header_border_gradient"
             alt="header_border_gradient">



        <img src="/objects/header/img/menu/qab/lower_gradient.png" id="header_background_lower_gradient"
             alt="header_lower_gradient">

        <img src="objects/header/img/backgrounds/prison_dark.png" alt="header_prison_dark"
             class="header_front_image" id="header_front_image_pdark">

        <img src="objects/header/img/backgrounds/cars_dark.png" alt="header_cars_dark"
             class="header_front_image" id="header_front_image_cdark">

        <div id="header_front_image_container">
            <div class="header_front_image" id="header_front_image_wrapper">
                <div class="header_front_image" id="header_nyc_image_wrapper">

                    <img src="objects/header/img/backgrounds/nyc.png" alt="header_nyc"
                         class="header_front_image" id="header_front_image_nyc">
                    <div id="header_background_text_wrapper"> 
                        <span id="header_energy_text">    ENERGY    </span> 
                        <span id="header_efficient_text"> EFFICIENT </span> 
                        <span id="header_lighting_text">  LIGHTING  </span> 
                    </div> 
                </div>
                <img src="/objects/header/img/menu/qab/glare.png" id="header_background_image_glare"
                     alt="header_glare">
                <div id="header_image_selection_container"> 
                    <div class="header_image_selection"> 
                        <img src="/objects/header/img/menu/qab/square_unselected.png"  id="header_su_1" alt="header_su_1"> 
                        <img src="/objects/header/img/menu/qab/square_unselected.png"  id="header_su_2" alt="header_su_2"> 
                        <img src="/objects/header/img/menu/qab/square_unselected.png"  id="header_su_3" alt="header_su_3"> 
                        <img src="/objects/header/img/menu/qab/square_unselected.png" id="header_su_4" alt="header_su_4"> 
                        <img src="/objects/header/img/menu/qab/square_unselected.png" id="header_su_5" alt="header_su_5"> 
                    </div> 
                </div>
            </div>
        </div>
    </div>

    <div id="header_content_container">
        <div id="header_top_bar_container">
            <div id="header_top_bar_left_buttons">
                <img src="/objects/header/img/au_cu/button_bg.png" id="header_au_cu_bg"
                     alt="header_au_cu_bg">
                <img src="/objects/header/img/au_cu/dividers.png" id="header_au_cu_dividers"
                     alt="header_au_cu_dividers">
                <img src="/objects/header/img/au_cu/gel_kids_grey.png" id="header_au_cu_gel_kids_grey"
                     alt="header_gel_kids_grey">
                <div id="header_top_bar_left_text_container">
                    <span class="header_top_bar_left_text" id="header_top_bar_about_us">   ABOUT US   </span>
                    <span class="header_top_bar_left_text" id="header_top_bar_contact_us"> CONTACT US </span>
                </div>
            </div>
            <div id="header_top_bar_center_container">
                <div id="header_top_bar_center_logo_container">
                    <img src="/objects/header/img/au_cu/twitter_logo.png" id="header_au_cu_twitter_logo"
                         alt="header_twitter_logo">
                    <span id="header_latest_tweet"> LATEST TWEET: </span>
                </div>
                <span id="header_top_bar_center_text_container"> </span>

            </div>

            <div id="header_top_bar_right_buttons">
                <img src="/objects/header/img/social_links/social_bg.png" id="header_social_bg"
                     alt="header_social_bg">
                <img src="/objects/header/img/social_links/dividers.png" id="header_social_dividers"
                     alt="header_social_dividers">
                <img src="/objects/header/img/social_links/facebook_logo.png" id="header_social_facebook_logo"
                     alt="header_social_facebook_logo">
                <img src="/objects/header/img/social_links/google_plus_logo.png" id="header_social_gp"
                     alt="header_social_gp">
                <img src="/objects/header/img/social_links/youtube_logo.png" id="header_social_yl"
                     alt="header_social_yl">
            </div>
        </div>
        <div id="header_quick_access_bar_wrapper">
            <div id="header_quick_access_bar_top_wrapper">
                <div id="header_quick_access_bar_top_links">
                    <a href="#/home">
                        <img src="/objects/header/img/menu/logo/header_gel_logo.png" id="header_gel_logo"
                             alt="header_gel_logo">
                    </a>
                    <img src="/objects/header/img/menu/menu/faded_divider.png" id="header_faded_dividers"
                         alt="header_faded_dividers">
                    <div id="header_top_bar_links_text_wrapper">
                        <span class="header_link_class" id="header_products_text">     PRODUCTS     </span>
                        <span class="header_link_class" id="header_order_text">        ORDER        </span>
                        <span class="header_link_class" id="header_case_studies_text"> CASE STUDIES </span>
                        <span class="header_link_class" id="header_resources_text">    RESOURCES    </span>
                    </div>
                </div>

            </div>
        </div>
    </div>

</div>

<script>
    //$('#header_background_images_container').header_replace_background("<img src=\"/objects/header/img/menu_logo_searcharea_cookie_crumbs/quick_access_bar/layer_446.png\" id=\"layer_432\">");
</script>